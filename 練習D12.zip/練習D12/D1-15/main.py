# 幾個字串資料
date_text = "2026-07-01"
csv = "apple,banana,cherry"
words = ["Python", "is", "fun"]

# TODO:
#       replaced：用 replace 把 date_text 裡的 "-" 換成 "/"
#       parts：用 split 把 csv 用 "," 切開
#       joined：用 join 把 words 用一個空格 " " 組成一句
replaced = ""
parts = []
joined = ""
