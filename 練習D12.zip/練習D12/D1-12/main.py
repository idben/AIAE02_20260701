# 一個字串
word = "Python"

# TODO:
#       head：取前 3 個字元
#       tail：取從索引 2 到最後
#       reversed_word：把整個字串反轉
head = ""
tail = ""
reversed_word = ""
