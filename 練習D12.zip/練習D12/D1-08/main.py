# Python 的 round() 用「銀行家捨入」：剛好是 .5 時，
# 會進位到「最接近的偶數」，而不是每次都進位。
# 先自己猜猜看結果，再用 round() 算出來對答案。

# TODO：用 round() 算出下面四個結果
r1 = None   # round(0.5)
r2 = None   # round(1.5)
r3 = None   # round(2.5)
r4 = None   # round(3.5)
