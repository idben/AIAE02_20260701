import subprocess
import sys
from pathlib import Path

import main as answer

# (要檢查的變數名稱, 預期值)
Check = tuple[str, object]

run_cases: list[Check] = [
    ("intro1", "我叫小明，今年18歲"),
    ("intro2", "我叫小美，今年25歲"),
]

submit_cases: list[Check] = run_cases


def test(name: str, expected: object) -> bool:
    print("---------------------------------")
    print(f"檢查變數：{name}")
    print(f"預期：    {expected!r}")
    if not hasattr(answer, name):
        print(f"錯誤：    main.py 裡找不到變數 {name}，請確認名稱有沒有拼對")
        return False
    result = getattr(answer, name)
    print(f"實際：    {result!r}")
    return result == expected


def play_pass_sound() -> None:
    sound_path = Path(__file__).resolve().parent.parent / "assets" / "levelup.mp3"
    try:
        if sys.platform == "darwin":
            subprocess.run(
                ["afplay", str(sound_path)],
                check=False,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
            )
    except Exception:
        pass


def main() -> None:
    passed = 0
    failed = 0
    skipped = len(submit_cases) - len(test_cases)
    for test_case in test_cases:
        correct = test(*test_case)
        if correct:
            passed += 1
            print("通過")
        else:
            failed += 1
            print("失敗")
    if failed == 0:
        print("============= 全部通過 ==============")
        play_pass_sound()
    else:
        print("============= 有測試失敗 ==============")
    if skipped > 0:
        print(f"通過 {passed} 筆，失敗 {failed} 筆，略過 {skipped} 筆")
    else:
        print(f"通過 {passed} 筆，失敗 {failed} 筆")


test_cases: list[Check] = submit_cases
if "__RUN__" in globals():
    test_cases = run_cases

main()
