# 一個字串
word = "Python"

# TODO:
#       first：取第一個字元(索引 0)
#       last：取最後一個字元(用負索引 -1)
#       length：取字串長度(用 len)
first = ""
last = ""
length = 0
