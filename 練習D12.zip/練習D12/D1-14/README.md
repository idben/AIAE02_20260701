# D1-14 練習：字串的尋找與判斷

## 題目

`main.py` 裡有 `s = "banana"`。
請算出下面四個結果：

- `pos`：字母 `"a"` 第一次出現的位置（用 `find`）→ `1`
- `cnt`：字母 `"a"` 出現幾次（用 `count`）→ `3`
- `has`：字串裡有沒有 `"nan"`（用 `in`）→ `True`
- `starts`：是不是以 `"ban"` 開頭（用 `startswith`）→ `True`

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `s.find("a")` 回傳第一次出現的索引位置（從 0 算）
- `s.count("a")` 回傳出現次數
- `"nan" in s` 的結果是布林值 `True` 或 `False`
- `s.startswith("ban")` 判斷開頭，結果也是布林值

## 這題常見錯誤

- `has` 和 `starts` 要存布林值 `True` / `False`，不要存數字或字串
- 以為 `find` 回傳的是次數（它回傳的是「位置」）

## 這題在測什麼

- 是否會用 `find` / `count` 尋找
- 是否會用 `in` / `startswith` 做判斷，並得到布林值
