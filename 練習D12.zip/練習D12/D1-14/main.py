# 一個字串
s = "banana"

# TODO:
#       pos：用 find 找出字母 "a" 第一次出現的位置
#       cnt：用 count 算出字母 "a" 出現幾次
#       has：用 in 判斷字串裡有沒有 "nan"(結果是 True 或 False)
#       starts：用 startswith 判斷是不是以 "ban" 開頭
pos = 0
cnt = 0
has = None
starts = None
