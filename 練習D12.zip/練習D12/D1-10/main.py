# 三個原始資料
num_text = "42"    # 字串
count = 100        # 整數
pi = 3.9           # 浮點數

# TODO：做型別轉換
#       n：把字串 num_text 轉成「整數」
#       f：把整數 count 轉成「浮點數」
#       s：把浮點數 pi 轉成「字串」
n = 0
f = 0.0
s = ""
