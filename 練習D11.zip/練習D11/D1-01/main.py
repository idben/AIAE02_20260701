# TODO：把字串 "Hello, World!" 存進變數 message
message = ""
