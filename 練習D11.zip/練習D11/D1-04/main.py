# 兩筆訂單的單價與數量(都是字串，想像成 input() 拿到的輸入)
price1 = "15"
count1 = "3"

price2 = "100"
count2 = "2"

# TODO：先用 int() 把字串轉成整數，再算出每筆訂單的總價(單價 × 數量)
#       第一筆存進 total1，第二筆存進 total2
total1 = 0
total2 = 0
