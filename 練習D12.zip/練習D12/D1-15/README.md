# D1-15 練習：取代、分割與組合

## 題目

`main.py` 裡有 `date_text = "2026-07-01"`、`csv = "apple,banana,cherry"`、`words = ["Python", "is", "fun"]`。
請做下面三件事：

- `replaced`：把 `date_text` 裡的 `"-"` 換成 `"/"` → `"2026/07/01"`
- `parts`：把 `csv` 用 `","` 切開 → `["apple", "banana", "cherry"]`
- `joined`：把 `words` 用一個空格 `" "` 組成一句 → `"Python is fun"`

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `date_text.replace("-", "/")` 把所有 `-` 換成 `/`
- `csv.split(",")` 用逗號切開，會得到一個串列
- `" ".join(words)` 用空格把串列組回一個字串

## 這題常見錯誤

- `split` 和 `join` 的呼叫對象弄反：切開是「字串.split()」，組合是「分隔字串.join(串列)」
- `replace` 後別忘了把結果存回 `replaced`

## 這題在測什麼

- 是否會用 `replace` 取代
- 是否會用 `split` 分割、`join` 組合
