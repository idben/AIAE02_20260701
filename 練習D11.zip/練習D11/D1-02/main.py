# 這兩個人的資料已經幫你準備好(不用改)
name1 = "小明"
age1 = 18

name2 = "小美"
age2 = 25

# TODO：用 f-string，把名字和年齡套進格式："我叫{名字}，今年{年齡}歲"
#       用 name1/age1 組出 intro1，用 name2/age2 組出 intro2
#       中間是全形逗號「，」，數字和「歲」之間不要有空格
intro1 = ""
intro2 = ""
