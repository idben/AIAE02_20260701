# D1-13 練習：大小寫與去空白

## 題目

`main.py` 裡有 `text = "hello world"`、`loud = "PYTHON"`、`messy = "   資策會   "`。
請做下面四件事：

- `up`：把 `text` 全部轉大寫 → `"HELLO WORLD"`
- `low`：把 `loud` 全部轉小寫 → `"python"`
- `titled`：把 `text` 每個單字字首大寫 → `"Hello World"`
- `clean`：把 `messy` 前後的空白去掉 → `"資策會"`

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

```bash
python3 test.py
```

## 提示

- `text.upper()` 轉大寫、`loud.lower()` 轉小寫
- `text.title()` 每個單字字首大寫
- `messy.strip()` 去掉字串前後的空白

## 這題常見錯誤

- 這些方法後面別忘了小括號，例如寫 `text.upper` 少了 `()` 就不會執行
- `strip()` 只去「前後」空白，不會去掉字中間的空白

## 這題在測什麼

- 是否會用 `upper()` / `lower()` / `title()`
- 是否會用 `strip()` 去除前後空白
