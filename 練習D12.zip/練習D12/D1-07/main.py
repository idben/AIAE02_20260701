# 正方形的邊長，以及要計算的次方
side = 4
base = 2
exp = 10

# TODO：用次方運算子 ** 算出
#       area：邊長的平方(side 的 2 次方)
#       power：base 的 exp 次方
area = 0
power = 0
