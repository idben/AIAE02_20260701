# 這四個值已經幫你準備好(不用改)
a = 3
b = 1.5
c = "hi"
d = True

# TODO：用 type() 找出每個值的型別名稱，存成字串(例如整數的型別名稱是 "int")
#       提示：type(某個值).__name__ 會得到型別名稱的字串
#       四個值請分別存進 a_type、b_type、c_type、d_type
a_type = ""
b_type = ""
c_type = ""
d_type = ""
