# 三位學生的分數
score1 = 60
score2 = 45
score3 = 90

# TODO：判斷每個分數是否及格(>= 60 算及格)
#       及格存 True，不及格存 False
#       提示：用比較運算子 >=，比較的結果本身就是 True 或 False
pass1 = None
pass2 = None
pass3 = None
