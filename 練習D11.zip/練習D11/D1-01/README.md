# D1-01 練習：第一支程式 Hello World

## 題目

在 `main.py` 裡，把字串 `Hello, World!` 存進變數 `message`。

這題最簡單，目的是先讓你熟悉「改 `main.py` → 跑 test → 看結果」的流程。

## 檔案

- `main.py`：你要改的檔案
- `test.py`：執行驗證（不用改）

## 執行方式

在這個資料夾內執行：

```bash
python3 test.py
```

## 提示

- 測試會檢查 `main.py` 裡的變數 `message`
- 讓 `message` 等於 `"Hello, World!"`（大小寫、逗號、空格都要一樣）

## 學生操作步驟

1. 打開 `main.py`
2. 把 `message = ""` 改成 `message = "Hello, World!"`
3. 存檔後，在這個資料夾執行 `python3 test.py`
4. 觀察畫面中的 `預期` 和 `實際`
5. 如果最後看到 `============= 全部通過 ==============`，代表這題完成

## 這題常見錯誤

- 大小寫不對，寫成 `"hello, world!"`
- 少了逗號或空格，寫成 `"Hello,World!"`
- 變數名稱拼錯（例如寫成 `massage`），測試會提示找不到 `message`

## 這題在測什麼

- 是否會用變數存一個字串
- 字串內容是否和題目完全一致
