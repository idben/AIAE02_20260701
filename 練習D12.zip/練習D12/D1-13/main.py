# 幾個字串
text = "hello world"
loud = "PYTHON"
messy = "   資策會   "

# TODO:
#       up：把 text 全部轉大寫
#       low：把 loud 全部轉小寫
#       titled：把 text 每個單字字首大寫
#       clean：把 messy 前後的空白去掉
up = ""
low = ""
titled = ""
clean = ""
